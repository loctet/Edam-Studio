open Types
open Printf
open Random
open Str
open Helper
open Printer
open Core_functions
open Test_generation

(*******)

(*Code of  the model here*)
  

(* Define the multi_config structure *)
let configurations : multi_config = {
  dafsm_map = Hashtbl.create 1;
  config_map = Hashtbl.create 1;
}


(* Define the DAFSM (including name and roles list) *)
let digitallocker_instance = 
{
  name = "DigitalLocker";
  states = [State "S0"; State "S1"; State "S2"; State "S3"; State "S3P"; State "S4"; State "S5"];
  transitions = [(
      State "_",
      (
        (Val (BoolVal(true)), []),
        (fun p -> match p with | _ -> (fun _ -> Unknown)),
        Ptp "o",
        Operation "start",
        [Ptp "ba"],
        [(VarT "string", Var "_lock_id")],
        [(Var "lock_id", Dvar(Var("_lock_id")))],
        (fun p -> match p with | Ptp "o" -> (fun  r -> if r = Role "Owner" then Top else Unknown) | Ptp "ba" -> (fun  r -> if r = Role "Banker" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        ""
      ),
      State "S0"
    ); (
      State "S0",
      (
        (Val (BoolVal(true)), []),
        (fun p -> match p with | Ptp "ba" -> (fun  r -> if r = Role "Banker" then Unknown else Unknown) | _ -> (fun _ -> Unknown)),
        Ptp "ba",
        Operation "BeginReview",
        [],
        [],
        [],
        (fun p -> match p with | Ptp "ba" -> (fun  r -> if r = Role "Banker" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        ""
      ),
      State "S1"
    ); (
      State "S1",
      (
        (Val (BoolVal(true)), []),
        (fun p -> match p with | Ptp "ba" -> (fun  r -> if r = Role "Banker" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        Ptp "ba",
        Operation "UploadDocument",
        [],
        [(VarT "string", Var "_lock_id"); (VarT "string", Var "_image")],
        [(Var "image", Dvar(Var("_image"))); 
(Var "lock_id", Dvar(Var("_lock_id")))],
        (fun p -> match p with | Ptp "ba" -> (fun  r -> if r = Role "Banker" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        ""
      ),
      State "S2"
    ); (
      State "S2",
      (
        (Val (BoolVal(true)), []),
        (fun p -> match p with | Ptp "tpr" -> (fun  r -> if r = Role "TrdParty" then Unknown else Unknown) | _ -> (fun _ -> Unknown)),
        Ptp "tpr",
        Operation "RequestLockAccess",
        [],
        [],
        [],
        (fun p -> match p with | Ptp "tpr" -> (fun  r -> if r = Role "TrdParty" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        ""
      ),
      State "S4"
    ); (
      State "S2",
      (
        (Val (BoolVal(true)), []),
        (fun p -> match p with | Ptp "ba" -> (fun  r -> if r = Role "Banker" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        Ptp "ba",
        Operation "Terminate",
        [],
        [],
        [],
        (fun p -> match p with | Ptp "cau" -> (fun  r -> if r = Role "CAU" then Bottom else Unknown) | _ -> (fun _ -> Unknown)),
        ""
      ),
      State "S5"
    ); (
      State "S3",
      (
        (Val (BoolVal(true)), []),
        (fun p -> match p with | Ptp "o" -> (fun  r -> if r = Role "Owner" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        Ptp "o",
        Operation "RevokeAccessLock",
        [],
        [],
        [],
        (fun p -> match p with | Ptp "cau" -> (fun  r -> if r = Role "CAU" then Bottom else Unknown) | _ -> (fun _ -> Unknown)),
        ""
      ),
      State "S2"
    ); (
      State "S3",
      (
        (Val (BoolVal(true)), []),
        (fun p -> match p with | Ptp "cau" -> (fun  r -> if r = Role "CAU" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        Ptp "cau",
        Operation "ReleaseLockAccess",
        [],
        [],
        [],
        (fun p -> match p with | Ptp "cau" -> (fun  r -> if r = Role "CAU" then Bottom else Unknown) | Ptp "tpr" -> (fun  r -> if r = Role "TrdParty" then Bottom else Unknown) | _ -> (fun _ -> Unknown)),
        ""
      ),
      State "S2"
    ); (
      State "S3",
      (
        (Val (BoolVal(true)), []),
        (fun p -> match p with | Ptp "ba" -> (fun  r -> if r = Role "Banker" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        Ptp "ba",
        Operation "Terminate",
        [],
        [],
        [],
        (fun p -> match p with | Ptp "cau" -> (fun  r -> if r = Role "CAU" then Bottom else Unknown) | _ -> (fun _ -> Unknown)),
        ""
      ),
      State "S5"
    ); (
      State "S4",
      (
        (Val (BoolVal(true)), []),
        (fun p -> match p with | Ptp "o" -> (fun  r -> if r = Role "Owner" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        Ptp "o",
        Operation "RejectSharingLock",
        [],
        [],
        [],
        (fun p -> match p with | Ptp "cau" -> (fun  r -> if r = Role "CAU" then Bottom else Unknown) | _ -> (fun _ -> Unknown)),
        ""
      ),
      State "S2"
    ); (
      State "S4",
      (
        (Val (BoolVal(true)), []),
        (fun p -> match p with | Ptp "o" -> (fun  r -> if r = Role "Owner" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        Ptp "o",
        Operation "AcceptSharingLock",
        [],
        [],
        [],
        (fun p -> match p with | Ptp "cau" -> (fun  r -> if r = Role "CAU" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        ""
      ),
      State "S3P"
    ); (
      State "S3P",
      (
        (Val (BoolVal(true)), []),
        (fun p -> match p with | Ptp "o" -> (fun  r -> if r = Role "Owner" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        Ptp "o",
        Operation "ShareW3rdP",
        [Ptp "tpr"],
        [],
        [],
        (fun p -> match p with | Ptp "tpr" -> (fun  r -> if r = Role "TrdParty" then Top else Unknown) | _ -> (fun _ -> Unknown)),
        ""
      ),
      State "S3"
    )];
  final_modes = []; 
  initial_state = State "_";
  roles_list = [Role "Owner"; Role "Banker"; Role "TrdParty"; Role "CAU"];
  ptp_var_list = [];
  variables_list = [Var "lock_id"; Var "image"]
}

let list_of_vars = [(VarT "string", Var "lock_id"); (VarT "string", Var "image")]


let lambda_digitallocker = fun _ -> []
(* Define the initial DAFSM configuration *)
let initial_config_digitallocker = {
  state = State "_";
  lambda = lambda_digitallocker;
  sigma = initialize_sigma list_of_vars;
}

(* Add to the multi_config *)
let () =
  Hashtbl.add configurations.dafsm_map digitallocker_instance.name digitallocker_instance;
  Hashtbl.add configurations.config_map digitallocker_instance.name initial_config_digitallocker




(* Define the dependencies map for all DAFSMs *)
let dependencies_map : dependencies_map = 
  let tbl = Hashtbl.create 1 in
(* Define the dependency for digitallocker *)
  let dependency_digitallocker = {
    required_calls = [];
    participant_roles = [];
    can_generate_participants = [];
    can_generate_participants_vars = [];
    transition_probabilities = Hashtbl.create 10;
  } in
  Hashtbl.add tbl digitallocker_instance.name dependency_digitallocker;
  tbl


(*End Code of  the model here*)

let () = 
  Random.self_init ();

  (* Define the DAFSM (including name and roles list) *)
  let server_configs: server_config_type = {
    probability_new_participant = 0.4;
    probability_right_participant = 0.9;
    probability_true_for_bool = 0.5;
    min_int_value = 0;
    max_int_value = 100;
    max_gen_array_size = 10;
    min_gen_string_length = 1;
    max_gen_string_length = 10;
    z3_check_enabled = true;
    latest_transitions = Hashtbl.create 10;
    executed_operations_log = Hashtbl.create 0;
    max_fail_try = 5;
    add_pi_to_test = false;
    add_test_of_state = true;
    add_test_of_variables = true;
  } in 
  print_endline "++++++++++++++++++++++++";
  (* Generate traces *)
  let traces = 
    List.init 500 (fun trace_idx ->
      let multi_cfg_copy = copy_multi_config configurations in
      let new_server_configs = {server_configs with latest_transitions = Hashtbl.create 10; executed_operations_log = Hashtbl.create 0} in
      let (symbolic_trace, generated_trace) = 
        generate_random_trace multi_cfg_copy dependencies_map new_server_configs 
          40 5 (trace_idx + 1) 
      in
      let evaluated_traces = 
        List.map (fun trace -> 
          let evaluated_trace, _ = evaluate_trace (List.rev trace) (copy_multi_config configurations) in
          evaluated_trace
        ) generated_trace 
      in 
      print_symbolic_trace symbolic_trace (trace_idx + 1);
      print_endline "++++++++++++++++++++++++";
      evaluated_traces
    ) 
    |> List.concat 
  in

  print_endline "________";

  (* Generate and print migration and test scripts for all traces *)
  let migration_code, test_code = generate_hardhat_tests configurations traces server_configs in
  print_endline test_code;
  print_endline "________";
  print_endline migration_code;
